// M.Wildan Humaidi Sutia Budi

/**
 * Goal tahun ini:
 * 1. Magang.
 * 2. Menjadi Manusia Yang Hari Demi Hari Lebih Baik.
 */